

//contact details
global.ownernomer = "0689616601"
global.dev = ["0689616601","0689616601"]
global.ownername = "moreno"
global.ytname = "moreno"
global.socialm = "GitHub: moreno"
global.location = "maroc, cairo, shopra"

global.ownernumber = '0689616601'  //creator number
global.ownername = 'moreno' //owner name
global.botname = 'Bot Crash   🌴' //name of the bot

//sticker details
global.packname = '\n\n\n\n\n\n\nSticker By'
global.author = 'moreno⚉\n\nContact: 0689616601'

//console view/theme
global.themeemoji = '🪀'
global.wm = "محمد"

//theme link
global.link = 'https://t.me/l9irche_13x1'
global.idch = '120363422217202244@newsletter'

global.baileysDB = 'baileysDB.json'
global.botDb = 'database.json'

//prefix
global.prefa = ['','!','.',',','🐤','🗿'] 

global.limitawal = {
    premium: "Infinity",
    free: 20
}

//menu type 
//v1 is image menu, 
//v2 is link + image menu,
//v3 is video menu,
//v4 is call end menu
global.typemenu = 'v1'

// Global Respon
global.mess = {
    success: 'Done✓',
    admin: `\`[ # ]\` This Command Can Only Be Used By Group Admins !`,
    botAdmin: `\`[ # ]\` This Command Can Only Be Used When Bot Becomes Group Admin !`,
    OnlyOwner: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nTelegram: @VIP_X1B\nWhatsApp: +212689616601`,
    OnlyGrup: `\`[ # ]\` This Command Can Only Be Used In Group Chat !`,
    private: `\`[ # ]\` This Command Can Only Be Used In Private Chat !`,
    wait: `\`[ # ]\` Wait Wait a minute`,
    notregist: `\`[ # ]\` You are not registered in the Bot Database. Please register first.`,
    premium: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nYouTube: @VIP_X1B\nTelegram:@VIP_X1B \nWhatsApp: +212689616601`,
}

// ملف config.js
module.exports = {
    banner: [
        "0689616601@s.whatsapp.net",
        "212@s.whatsapp.net",
        "0689616601@s.whatsapp.net",
        "212@s.whatsapp.net",
        "212@s.whatsapp.net",
        "212@s.whatsapp.net"
    ]
};

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})