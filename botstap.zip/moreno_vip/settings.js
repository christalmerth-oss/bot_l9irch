
const fs = require("fs");
const chalk = require("chalk")

global.BOT_TOKEN = "8936419964:AAEbzLFfs2-ayT2JOqn-NSgDr18swaOpmac" // create bot here https://t.me/Botfather and get bot token
global.BOT_NAME = "moreno»࿅ 𓈪" //your bot name
global.OWNER_NAME = "https://t.me/l9irch_13x1" //your name with sign @
global.OWNER = ["https://t.me/l9irch_13x1", "https://t.me/l9irch_13x1"] // Make sure the username is correct so that the special owner features can be used.
global.DEVELOPER = ["7826514908"] //developer telegram id to operate addprem delprem and listprem
global.pp = 'https://pin.it/5W3wbURdm' //your bot pp


//approval
global.GROUP_ID = -1003847121253; // Replace with your group ID
global.CHANNEL_ID =  -1003767592760; // Replace with your channel ID
global.GROUP_LINK = "https://t.me/l9irch_13"; // Replace with your group link
global.CHANNEL_INVITE_LINK = "https://t.me/l9irch_13x1_01"; // Replace with your private channel invite link
global.WHATSAPP_LINK = "https://wa.me/212689616601"; // Replace with your group link
global.YOUTUBE_LINK = "https://www.youtube.com/@l9irchee13x1"; // Replace with your youtube link
global.INSTAGRAM_LINK = "https://guns.lol/moreno13rock0"; // Replace with your ig link

global.owner = global.owner = ['+212689616601'] //owner whatsapp

const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})