global.ownernomer = "212689616601"
global.dev = ["","","", "","","212689616601"]
global.ownername = "13X1MO-𝐕1"
global.ytname = "13X1MO"
global.socialm = "GitHub: christalmerth"
global.location = "maroc, menofia, Ashmoun"

global.ownernumber = '212689616601'  //creator number
global.ownername = '13X1MO' //owner name
global.botname = '13X1TEAM V1' //name of the bot

//sticker details
global.packname = '\n\n\n\n\n\n\nSticker By'
global.author = '13X1TEM ⚉\n\nContact: 212689616601'

//console view/theme
global.themeemoji = '🪀'
global.wm = "13X1MO."

//theme link
global.link = 'https://whatsapp.com/channel/0029VbDDfqeA89Mb3gPfqV44'
global.idch = '120363386423395618@newsletter'

global.baileysDB = 'baileysDB.json'
global.botDb = 'database.json'

//prefix
global.prefa = ['','!','.',',','🐤','🗿'] 

global.limitawal = {
    premium: "Infinity",
    free: 20
}

//menu type 
//v1 is image menu, 
//v2 is link + image menu,
//v3 is video menu,
//v4 is call end menu
global.typemenu = 'v1'

// Global Respon
global.mess = {
    success: 'Done✓',
    admin: `\`[ # ]\` This Command Can Only Be Used By Group Admins !`,
    botAdmin: `\`[ # ]\` This Command Can Only Be Used When Bot Becomes Group Admin !`,
    OnlyOwner: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nTelegram: @l9irch_13x1\nWhatsApp: +212689616601`,
    OnlyGrup: `\`[ # ]\` This Command Can Only Be Used In Group Chat !`,
    private: `\`[ # ]\` This Command Can Only Be Used In Private Chat !`,
    wait: `\`[ # ]\` Wait Wait a minute`,
    notregist: `\`[ # ]\` You are not registered in the Bot Database. Please register first.`,
    premium: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nYouTube: @l9irchee13x1\nTelegram: @l9irch_13x1\nWhatsApp: +212689616601`,
}

module.exports = {

    banner: [


        "212689616601@s.whatsapp.net",


    ]

};

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})